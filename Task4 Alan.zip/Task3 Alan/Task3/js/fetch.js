let urlsrc
if(document.querySelector("#senate")){
  urlsrc = "https://api.propublica.org/congress/v1/113/senate/members.json";
}
else if (document.querySelector("#house")){
  urlsrc = "https://api.propublica.org/congress/v1/113/house/members.json";
}

const app = new Vue({
  el: "#app",
  data: {
    url: urlsrc,
    init: {
      method: "GET",
      headers: {
        "X-API-Key": "BMvFaz2nxYWepqJal2Spn9nwn07Tplm2MbgfYWTX"
      }
    },
    members: [],
    parties: [],
    stateAct: "All",
    states: [],
    
    leastEngaged: [],
    mostEngaged: [],
    leastLoyal: [],
    mostLoyal: [],
    total: {Republican: {reps: 0, votes: 0},Democrat: {reps: 0, votes: 0},Independant: {reps: 0, votes: 0},totalreps: {reps: 0}}
  },
  created(){
    fetch(this.url, this.init)
    .then(function(res){
      if(res.ok){
        return res.json()
      }
      else {
        throw new Error(res.status)
      }
    })
    .then(function(json){
      app.members = json.results[0].members;
      app.parties = app.getKeyValue(app.members, "party")
      app.states = app.getKeyValue(app.members, "state")
      app.leastEngaged = app.obtencionDeArray(app.members,"missed_votes_pct",false);
      app.mostEngaged = app.obtencionDeArray(app.members,"missed_votes_pct",true);
      app.leastLoyal = app.obtencionDeArray(app.members,"votes_with_party_pct",true);
      app.mostLoyal = app.obtencionDeArray(app.members,"votes_with_party_pct",false);
      app.votantesTotales();
    })
    .catch(function(error){
      console.log(error);
    })
  },
  methods:{
    votantesTotales(){
      app.members.forEach(m => {
        if(m.party == "R"){
          app.total.Republican.reps++;
          app.total.Republican.votes+= m.votes_with_party_pct;
        }
        else if(m.party == "D"){
          app.total.Democrat.reps++;
          app.total.Democrat.votes+= m.votes_with_party_pct;
        }
        else {
          app.total.Independant.reps++;
          app.total.Independant.votes+= m.votes_with_party_pct;
        }
        app.total.totalreps.reps++;
      })
      app.total.Republican.votes = app.total.Republican.votes!=0?app.total.Republican.votes/app.total.Republican.reps:0;
      app.total.Democrat.votes = app.total.Democrat.votes!=0?app.total.Democrat.votes/app.total.Democrat.reps:0;
      app.total.Independant.votes = app.total.Independant.votes!=0?app.total.Independant.votes/app.total.Independant.reps:0;
    },
    getKeyValue(array,key){
      let result = []
      array.forEach(e => !result.includes(e[key]) ? result.push(e[key]) : null);
      return result
    },
    obtencionDeArray(array,key,orden){
      let result = [];
      let aux = array.filter(m => m.total_votes != 0);
      aux = orden?aux.sort((a,b) => a[key] - b[key]):aux.sort((a,b) => b[key] - a[key])
      let porcentaje = parseInt(aux.length*0.1);
      let i = 0;
      while(i<porcentaje || aux[i][key] == aux[i-1][key]){
        result.push(aux[i]);
        i++;
      }
      return result;
    }
  },
    computed:{
      filterMembers(){
        return this.members.filter(m => app.parties.includes(m.party) && (m.state == app.stateAct || app.stateAct == "All"))              
      }  
    }
  })